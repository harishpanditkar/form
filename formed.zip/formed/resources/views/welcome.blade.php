@extends('layouts.install')



@section('content')
    <div class="max-w-5xl mx-auto px-4">
        <div class="w-full border border-gray-300 border rounded-lg">
            <div class="flex align-center justify-center">
                <div class="p-4 max-w-3xl space-y-10 w-full lg:w-1/2">


                </div>

            </div>
        </div>
    </div>
@endsection
