<h2 class="font-bold text-gray-900 tracking-tight text-2xl">
    {{ $content }}
</h2>
