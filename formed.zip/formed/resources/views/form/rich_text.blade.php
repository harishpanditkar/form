<div class="prose prose-lg rich-text">
    <p>
        {{ $content }}
    </p>
</div>
