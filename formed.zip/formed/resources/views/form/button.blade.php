<button type="submit"
        style="background-color:{{ $bg_color }};color: {{ $text_color }}"
 class="rounded focus:ring-2 focus:ring-blue-300 focus:outline-none block w-full text-center font-semibold tracking-tight rounded py-4 transition-colors duration-100 ease-out remove-outline focus:outline-none"
   >{{ $text }}
</button>
