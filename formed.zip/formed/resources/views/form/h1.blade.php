<h1 class="font-bold text-gray-900 tracking-tight text-3xl">
    {{ $content }}
</h1>
