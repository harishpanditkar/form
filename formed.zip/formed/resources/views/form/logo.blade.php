@if($src)
    <div class="w-full flex items-center justify-center"><img src="{{ $src }}" class="{{ $class }}"></div>
@endif
