window.validate = el => {
    const checkboxGroupEls = el.target.querySelectorAll(".checkbox-group-required");
    let checkboxPassed = true;
    checkboxGroupEls.forEach(checkboxGroupEl => {
        let checkboxes = Array.from(checkboxGroupEl.querySelectorAll('input[type="checkbox"]')),
            checked = checkboxes.some(e => e.checked)
        if (!checked) {
            checkboxGroupEl.querySelector(".status-message").classList.remove('hidden')
            checkboxPassed = false
        } else {
            checkboxGroupEl.querySelector(".status-message").classList.add('hidden')
        }
    })

    if (!checkboxPassed) {
        el.preventDefault();
    }
}