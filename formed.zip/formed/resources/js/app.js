require('./bootstrap');
require('./fileUpload');
require('./validate');

import Alpine from 'alpinejs';

window.Alpine = Alpine;


Alpine.start();
