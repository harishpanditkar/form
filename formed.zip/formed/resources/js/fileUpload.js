
 window.onFileChoose = function(el) {

    el.getElementsByClassName('file-upload')[0].click()
}

window.onFileDrop = function (el, event) {
    event.preventDefault();
    let file= Array.from(event.dataTransfer.files)[0],
        type = JSON.parse(el.getAttribute('data-type')),
        maxSize = el.getAttribute('data-max-size'),
        fileName = file.name,
        ext = fileName.toLowerCase().substr(fileName.lastIndexOf("."));

    if (type.length !== 0 && type.indexOf(ext) === -1) {
        alert("Only supports upload of " + type.join(",") + " file type")
        return;
    }

    if (maxSize && file.size > maxSize * 1024 * 1024) {
        alert("Upload file exceeds limit.")
        return;
    }
    let fileEl =  el.getElementsByClassName('file-upload')[0]

    window.onUpload(file, fileEl)

    fileEl.removeAttribute('required')
}

window.onFileDragEnter = function (event) {
    event.preventDefault()
}

window.onFileDragOver = function (event) {
    event.preventDefault()
}

window.onFileChange = function(el) {
    let file = el.files[0],
        type = JSON.parse(el.getAttribute('data-type')),
        maxSize = el.getAttribute('data-max-size'),
        fileName = file.name,
        ext = fileName.toLowerCase().substr(fileName.lastIndexOf("."));

    if (type.length !== 0 && type.indexOf(ext) ===  -1) {
        alert("Only supports upload of " + type.join(",") + " file type")
        return;
    }

    if (maxSize && file.size > maxSize * 1024 * 1024) {
        alert("Upload file exceeds limit.")
        return;
    }

    window.onUpload(file, el)
}

window.onUpload = function(file, el) {
    if (file) {
        const formData = new FormData()
        formData.append('images', file)

        axios.post('/admin/upload', formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            },
        }).then(res => {
            el.nextElementSibling.innerHTML = `
        <img class="w-full" src="` + res.data.url + `">
        `
            el.previousElementSibling.setAttribute('value', res.data.url)
        }).catch(err => {
            window.alert('上传图片失败')
        })
    }
}
