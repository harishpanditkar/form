<?php
namespace App\Admin\Forms\Exceptions;

class FormsLimitException extends \Exception
{

}