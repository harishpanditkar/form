<?php
namespace App\Admin\Forms\Repositories;

class FormRepository
{
}