<?php
namespace App\Admin\Forms\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class FormRequest extends \Illuminate\Foundation\Http\FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'branding' => 'required',
            'id' => 'required',
            'name' => 'required',
            'pages' => 'required',
            'slug' => 'required',
            'redirect' => 'required_if:thank_you_page.redirect,true'
        ];
    }

    public function messages()
    {
        return [
            'redirect.required_if' => 'Do not allow empty value when Redirect after submission is ON.'
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        $error = $validator->errors()->all();
        throw new HttpResponseException(response()->json(['message' => $error[0]], 422));
    }
}