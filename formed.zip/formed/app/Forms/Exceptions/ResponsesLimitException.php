<?php
namespace App\Forms\Exceptions;

class ResponsesLimitException extends \Exception
{

}