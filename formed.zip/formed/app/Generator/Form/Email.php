<?php
namespace App\Generator\Form;

class Email extends Input
{
    public string $view = 'form.email';
}