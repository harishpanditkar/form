<?php
namespace App\Generator\Form;

use Illuminate\Contracts\Support\Renderable;

class Textarea extends Input
{
    public string $view = "form.textarea";

}