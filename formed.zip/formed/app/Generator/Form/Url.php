<?php
namespace App\Generator\Form;

class Url extends Input
{
    public string $view = 'form.url';
}