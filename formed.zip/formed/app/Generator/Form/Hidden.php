<?php
namespace App\Generator\Form;

class Hidden extends Input
{
    public string $view = "form.hidden";
}