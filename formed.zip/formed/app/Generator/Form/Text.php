<?php
namespace App\Generator\Form;

class Text extends Input
{

}