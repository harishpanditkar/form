<?php
namespace App\Generator\Form;

use Illuminate\Contracts\Support\Renderable;

class FileUpload implements Renderable
{
    public string $view = 'form.file_upload';

    public ?string $url;
    public ?string $label;
    public string $id;
    public bool $required;
    public ?string $help;
    public ?int $maxSize;
    public ?array $fileType;

    public function __construct(array $params)
    {
        $this->id = data_get($params, 'id');
        $this->url = data_get($params, 'url');
        $this->label = data_get($params, 'label');
        $this->required = data_get($params, 'required');
        $this->help = data_get($params, 'help');
        $this->maxSize = data_get($params, 'max_size');
        $fileType = data_get($params, 'file_type', []);
        $this->fileType = $fileType ? array_map(fn($type) => "." . strtolower($type) ,$fileType) : [];
    }

    public function render()
    {
        return view($this->view, [
            'id' => $this->id,
            'url' => $this->url,
            'label' => $this->label,
            'required' => $this->required,
            'help' => $this->help,
            'maxSize' => $this->maxSize,
            'fileType' => $this->fileType
        ]);
    }


}