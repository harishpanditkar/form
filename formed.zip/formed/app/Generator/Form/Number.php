<?php
namespace App\Generator\Form;

class Number extends Input
{
    public string $view = 'form.number';
}