<?php
if (! function_exists('is_file_path')) {
    /**
     * @param  string  $val
     * @return bool
     */
    function is_file_path(string $val): bool
    {
        $ext = strtolower(last(explode(".", $val)));
        return in_array($ext, ['jpg', 'png', 'gif', 'pdf', 'csv', 'word', 'excel']);
    }
}