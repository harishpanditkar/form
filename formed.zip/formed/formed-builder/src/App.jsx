import Home from './pages/Home/Home'
import './App.css'

function App() {

  return (
    <div>
      <Home />
    </div>
  )
}

export default App
