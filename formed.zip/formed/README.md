# Formed

A self-hosted form builder 

## Install

* ### About  php
```
php artisan install

```

* ### About js

```shell
cd formed-builder
```

```shell
yarn prod 
```

```shell
yarn dev 
```

* ### How to set admin


Set `admin_emails` in `config/auth.php`
