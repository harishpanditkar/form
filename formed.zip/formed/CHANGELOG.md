## Version 1.6
+ Fixed the redirect issue after admin login

## Version 1.5
+ Fixed checkbox validation bug

## Version 1.4

+ Fixed empty text submission bug.
+ Added new input type: file uploader.

## Version 1.3

+ Fixed empty text submission bug
+ Added new input type: file uploader

## Version 1.2

+ Added Logo uploader.
+ Added pagination to form page.
+ Fixed invoice page selection bug

## Version 1.1

+ Updated the SaaS registration flow
+ Improved the Stripe payment process
+ Added a Setting module to better manage website's settings


## Version 1.0 

+ Initial release 
